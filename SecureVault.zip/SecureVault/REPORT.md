# SecureVault - Mobile Forensics & Security Project Report

## 1. Project Abstract
SecureVault is an Android application designed for educational purposes in the field of Mobile Forensics and Security. The project demonstrates the stark contrast between insecure and secure mobile application development practices. It provides a hands-on environment for students and researchers to perform reverse engineering, forensic analysis, and security hardening. The app includes modules for authentication, secure data storage (Notes & Files), and device forensics.

## 2. Problem Statement
Mobile applications often handle sensitive user data such as credentials, personal notes, and files. Inexperienced developers may inadvertently store this data insecurely (e.g., hardcoded strings, plaintext XML/files), making it vulnerable to extraction by attackers with physical access or malware. Understanding these vulnerabilities and their mitigations is crucial for modern Android security.

## 3. Objectives
- To demonstrate common Android security vulnerabilities (Hardcoding, Plaintext Storage).
- To implement secure alternatives using Industry Best Practices (Hashing, AES Encryption, Keystore).
- To provide a platform for practicing Mobile Forensics (Data extraction from `/data/data/`).
- To analyze the effectiveness of obfuscation and encryption against reverse engineering.

## 4. System Architecture
The application is built using native Android (Java/XML) and consists of four primary modules:
1.  **Authentication Module**: Comparison of Hardcoded vs. Hashed (SHA-256) credentials.
2.  **Secure Notes Module**: Comparison of SharedPreferences (Plaintext) vs. AES Encrypted storage.
3.  **File Locker Module**: Comparison of raw File I/O vs. Encrypted File I/O.
4.  **Forensics Module**: Extraction of device identifiers and application access logs.

## 5. Vulnerability Analysis & Implementation

### Module 1: Login & Authentication
-   **Vulnerable**: Credentials (`admin` / `supersecret123`) are hardcoded in `LoginActivity.java`.
    -   *Attack*: Decompile APK using JADX -> Open `LoginActivity` -> View strings.
-   **Secure**: Credentials are hashed using SHA-256 + Salt.
    -   *Defense*: Even if decompiled, the attacker only sees a hash, not the password.

### Module 2: Secure Notes
-   **Vulnerable**: Notes stored in `VulnerableNotes.xml` in `SharedPreferences`.
    -   *Attack*: `adb shell cat /data/data/com.securevault.mfs/shared_prefs/VulnerableNotes.xml`
-   **Secure**: Notes encrypted with AES before storage.
    -   *Defense*: The XML file contains unreadable Base64 ciphertext.

### Module 3: File Locker
-   **Vulnerable**: Files saved directly to Internal Storage (`secret_evidence.txt`).
    -   *Attack*: Extract file via ADB or Root File Explorer.
-   **Secure**: Content encrypted with AES before writing to `secure_evidence.enc`.
    -   *Defense*: File content is scrambled; extracting the file yields no usable information without the key.

## 6. Forensics & Evidence
The application generates artifacts useful for forensic investigation:
-   **Timestamps**: Logged in `ForensicsActivity`.
-   **Device IDs**: Captured in `DeviceInfoActivity`.
-   **Data Residue**: Left in `/data/data/com.securevault.mfs/` (databases, shared_prefs, files).

## 7. Anti-Analysis & Security Controls
The Secure version of the app includes advanced defenses to prevent reverse engineering and tampering:
-   **Root Detection**: Checks for known root binaries (`su`, `busybox`) and test-keys.
-   **Debugger Detection**: Uses `android.os.Debug.isDebuggerConnected()` to detect attached debuggers (e.g., JDB, Android Studio).
-   **Emulator Detection**: Checks build properties (fingerprint, hardware) to identify emulated environments.
-   **Code Obfuscation**: Uses **R8/ProGuard** (`isMinifyEnabled = true`) in release builds to rename classes/methods and strip debug info, making decompilation significantly harder.

## 8. UI & User Experience Enhancements
The application interface has been redesigned to follow **Material Design** principles for better usability and visual appeal:
-   **Card-Based Layouts**: Content is grouped into `CardView` containers with elevation and rounded corners for better hierarchy.
-   **Input Improvements**: `TextInputLayout` with `OutlinedBox` style is used for all input fields to provide better feedback and aesthetics.
-   **Visual Feedback**: Distinct color schemes are used to differentiate modules (Red for Vulnerable, Green for Secure, Blue for Forensics).
-   **Scrollable Views**: `ScrollView` is implemented in all activities to ensure accessibility on smaller screens.

## 9. Conclusion
SecureVault successfully demonstrates that security must be designed into the application from the ground up. While functional features can be implemented insecurely with ease, adding security requires deliberate use of cryptography and secure storage APIs. This project serves as a comprehensive lab for understanding the offensive and defensive sides of mobile security.

## 10. Viva Questions
1.  **Q: What is the difference between SharedPreferences and Internal Storage?**
    *   A: SharedPreferences is for key-value pairs (XML), Internal Storage is for files. Both are private to the app but accessible via Root/ADB.
2.  **Q: Why is Base64 used in encryption?**
    *   A: Encryption produces raw bytes; Base64 encodes them into a string safe for storage in text files/XML.
3.  **Q: How does SHA-256 differ from AES?**
    *   A: SHA-256 is a one-way hash (cannot be decrypted), used for passwords. AES is two-way encryption (can be decrypted), used for data storage.
4.  **Q: What tool is used to reverse engineer Android apps?**
    *   A: JADX, APKTool, or Ghidra.
