package com.securevault.mfs;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class SecureFileActivity extends AppCompatActivity {

    private EditText etFileContent;
    private Button btnSaveFile;
    private TextView tvFilePath, tvDecryptedContent, tvRawContent;
    private final String FILENAME = "secure_evidence.enc";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secure_files);

        etFileContent = findViewById(R.id.etFileContent);
        btnSaveFile = findViewById(R.id.btnSaveFile);
        tvFilePath = findViewById(R.id.tvFilePath);
        tvDecryptedContent = findViewById(R.id.tvDecryptedContent);
        tvRawContent = findViewById(R.id.tvRawContent);

        loadFile();

        btnSaveFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = etFileContent.getText().toString();
                try {
                    // SECURE: Encrypt data before writing to file
                    String encryptedData = CryptoUtils.encrypt(data);
                    
                    FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
                    fos.write(encryptedData.getBytes());
                    fos.close();
                    
                    Toast.makeText(SecureFileActivity.this, "File Encrypted & Saved!", Toast.LENGTH_SHORT).show();
                    loadFile();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(SecureFileActivity.this, "Encryption Error", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadFile() {
        try {
            FileInputStream fis = openFileInput(FILENAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text);
            }
            String encryptedContent = sb.toString();
            
            tvFilePath.setText("Location: " + getFilesDir() + "/" + FILENAME);
            tvRawContent.setText("Raw Encrypted File Content:\n" + encryptedContent);
            
            try {
                String decrypted = CryptoUtils.decrypt(encryptedContent);
                tvDecryptedContent.setText("Decrypted Content:\n" + decrypted);
            } catch (Exception e) {
                tvDecryptedContent.setText("Decryption Failed");
            }

        } catch (Exception e) {
            tvRawContent.setText("No file found.");
        }
    }
}