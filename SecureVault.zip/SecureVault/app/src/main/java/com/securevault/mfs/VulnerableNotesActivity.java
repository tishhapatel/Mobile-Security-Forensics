package com.securevault.mfs;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class VulnerableNotesActivity extends AppCompatActivity {

    private EditText etNote;
    private Button btnSave;
    private TextView tvSavedNote;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vulnerable_notes);

        etNote = findViewById(R.id.etNote);
        btnSave = findViewById(R.id.btnSave);
        tvSavedNote = findViewById(R.id.tvSavedNote);

        // VULNERABILITY: Storing data in MODE_PRIVATE is standard, but the data itself is PLAINTEXT.
        // A rooted device or adb backup can extract this easily.
        sharedPreferences = getSharedPreferences("VulnerableNotes", Context.MODE_PRIVATE);

        loadNote();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String note = etNote.getText().toString();
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("secret_note", note);
                editor.apply();
                Toast.makeText(VulnerableNotesActivity.this, "Note Saved!", Toast.LENGTH_SHORT).show();
                loadNote();
            }
        });
    }

    private void loadNote() {
        String note = sharedPreferences.getString("secret_note", "No note saved");
        tvSavedNote.setText("Stored: " + note);
    }
}