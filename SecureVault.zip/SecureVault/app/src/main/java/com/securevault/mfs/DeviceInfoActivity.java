package com.securevault.mfs;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DeviceInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_info);

        TextView tvInfo = findViewById(R.id.tvDeviceInfo);

        StringBuilder info = new StringBuilder();
        info.append("Manufacturer: ").append(Build.MANUFACTURER).append("\n");
        info.append("Model: ").append(Build.MODEL).append("\n");
        info.append("Device: ").append(Build.DEVICE).append("\n");
        info.append("Board: ").append(Build.BOARD).append("\n");
        info.append("Hardware: ").append(Build.HARDWARE).append("\n");
        info.append("Android Version: ").append(Build.VERSION.RELEASE).append("\n");
        info.append("SDK Level: ").append(Build.VERSION.SDK_INT).append("\n");
        info.append("Security Patch: ").append(Build.VERSION.SECURITY_PATCH).append("\n");
        info.append("Bootloader: ").append(Build.BOOTLOADER).append("\n");
        
        tvInfo.setText(info.toString());
    }
}