package com.securevault.mfs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Module 1: Login
        setupButton(R.id.btnVulnLogin, LoginActivity.class);
        setupButton(R.id.btnSecureLogin, SecureLoginActivity.class);

        // Module 2: Notes
        setupButton(R.id.btnVulnNotes, VulnerableNotesActivity.class);
        setupButton(R.id.btnSecureNotes, SecureNotesActivity.class);

        // Module 3: Files
        setupButton(R.id.btnVulnFiles, VulnerableFileActivity.class);
        setupButton(R.id.btnSecureFiles, SecureFileActivity.class);

        // Module 4: Info & Forensics
        setupButton(R.id.btnDeviceInfo, DeviceInfoActivity.class);
        setupButton(R.id.btnForensics, ForensicsActivity.class);
    }

    private void setupButton(int btnId, final Class<?> targetActivity) {
        findViewById(btnId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, targetActivity));
            }
        });
    }
}