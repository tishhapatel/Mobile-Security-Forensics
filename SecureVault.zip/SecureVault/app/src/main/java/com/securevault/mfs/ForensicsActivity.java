package com.securevault.mfs;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ForensicsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forensics);

        TextView tvLogs = findViewById(R.id.tvLogs);
        
        // Real Security Checks
        boolean isRooted = SecurityUtils.isDeviceRooted();
        boolean isDebugger = SecurityUtils.isDebuggerAttached();
        boolean isEmulator = SecurityUtils.isEmulator();

        // Simulate reading application logs
        StringBuilder logs = new StringBuilder();
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        
        logs.append("[").append(timestamp).append("] APP_START: MainActivity launched\n");
        logs.append("[").append(timestamp).append("] MODULE_ACCESS: Forensics Module accessed\n");
        
        // Log Real Security Status
        logs.append("[").append(timestamp).append("] CHECK: Root Access... ").append(isRooted ? "DETECTED (WARNING)" : "NEGATIVE").append("\n");
        logs.append("[").append(timestamp).append("] CHECK: Debugger... ").append(isDebugger ? "CONNECTED (WARNING)" : "DISCONNECTED").append("\n");
        logs.append("[").append(timestamp).append("] CHECK: Environment... ").append(isEmulator ? "EMULATOR" : "REAL DEVICE").append("\n");
        
        logs.append("[").append(timestamp).append("] INTEGRITY: Classes.dex hash verified\n");
        logs.append("[").append(timestamp).append("] IO: Read attempt on secure_evidence.enc\n");
        
        tvLogs.setText(logs.toString());
    }
}