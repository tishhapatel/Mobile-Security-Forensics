package com.securevault.mfs;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SecureNotesActivity extends AppCompatActivity {

    private EditText etNote;
    private Button btnSave;
    private TextView tvSavedNote, tvEncryptedRaw;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secure_notes);

        etNote = findViewById(R.id.etNote);
        btnSave = findViewById(R.id.btnSave);
        tvSavedNote = findViewById(R.id.tvSavedNote);
        tvEncryptedRaw = findViewById(R.id.tvEncryptedRaw);

        sharedPreferences = getSharedPreferences("SecureNotes", Context.MODE_PRIVATE);

        loadNote();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String note = etNote.getText().toString();
                try {
                    // SECURE: Encrypt before saving
                    String encryptedNote = CryptoUtils.encrypt(note);
                    
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("secret_note_enc", encryptedNote);
                    editor.apply();
                    
                    Toast.makeText(SecureNotesActivity.this, "Note Encrypted & Saved!", Toast.LENGTH_SHORT).show();
                    loadNote();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(SecureNotesActivity.this, "Encryption Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadNote() {
        String encryptedNote = sharedPreferences.getString("secret_note_enc", "");
        
        if (encryptedNote.isEmpty()) {
            tvSavedNote.setText("No note saved");
            tvEncryptedRaw.setText("Raw Data: [Empty]");
            return;
        }

        tvEncryptedRaw.setText("Raw Encrypted Data (What Hacker Sees):\n" + encryptedNote);

        try {
            String decryptedNote = CryptoUtils.decrypt(encryptedNote);
            tvSavedNote.setText("Decrypted: " + decryptedNote);
        } catch (Exception e) {
            tvSavedNote.setText("Decryption Failed!");
        }
    }
}