package com.securevault.mfs;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class VulnerableFileActivity extends AppCompatActivity {

    private EditText etFileContent;
    private Button btnSaveFile;
    private TextView tvFilePath, tvFileContent;
    private final String FILENAME = "secret_evidence.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vulnerable_files);

        etFileContent = findViewById(R.id.etFileContent);
        btnSaveFile = findViewById(R.id.btnSaveFile);
        tvFilePath = findViewById(R.id.tvFilePath);
        tvFileContent = findViewById(R.id.tvFileContent);

        loadFile();

        btnSaveFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = etFileContent.getText().toString();
                try {
                    // VULNERABILITY: Saving directly to internal storage without encryption
                    FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
                    fos.write(data.getBytes());
                    fos.close();
                    Toast.makeText(VulnerableFileActivity.this, "File Saved!", Toast.LENGTH_SHORT).show();
                    loadFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void loadFile() {
        try {
            FileInputStream fis = openFileInput(FILENAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            tvFileContent.setText("Content: " + sb.toString());
            tvFilePath.setText("Location: " + getFilesDir() + "/" + FILENAME);
        } catch (Exception e) {
            tvFileContent.setText("No file found.");
        }
    }
}