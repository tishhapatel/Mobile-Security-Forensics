package com.securevault.mfs;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SecureLoginActivity extends AppCompatActivity {

    private TextInputEditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvStatus;

    // SIMULATED DATABASE RECORD
    // Password: "SecurePassword123!"
    // Salt: "RandomSaltValue"
    // Hash = SHA256("SecurePassword123!" + "RandomSaltValue")
    // Use an online calculator or the code below to generate this during development
    private static final String EXPECTED_HASH = "d1c077b2184d09260c6753f7d983c509772d53d2d0937a09804245f94d493362"; 
    private static final String SALT = "RandomSaltValue";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secure_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvStatus = findViewById(R.id.tvStatus);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(SecureLoginActivity.this, "Please enter credentials", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                // ANTI-ANALYSIS CHECKS
                if (SecurityUtils.isDeviceRooted()) {
                    tvStatus.setText("SECURITY ALERT: Rooted Device Detected! Access Denied.");
                    tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                    return;
                }
                
                if (SecurityUtils.isDebuggerAttached()) {
                    tvStatus.setText("SECURITY ALERT: Debugger Detected! Access Denied.");
                    tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                    return;
                }

                // SECURE IMPLEMENTATION:
                // 1. Never compare plaintext passwords
                // 2. Hash the input with the same Salt
                // 3. Compare the Hashes
                String inputHash = hashPassword(password, SALT);

                if (username.equals("admin") && inputHash.equals(EXPECTED_HASH)) {
                    Toast.makeText(SecureLoginActivity.this, "Secure Login Successful!", Toast.LENGTH_SHORT).show();
                    tvStatus.setText("Access Granted via Secure Auth");
                } else {
                    tvStatus.setText("Invalid Credentials");
                }
            }
        });
    }

    private String hashPassword(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String input = password + salt;
            byte[] hash = digest.digest(input.getBytes());
            
            // Convert byte array to Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        }
    }
}