package com.example.locationtracker.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.locationtracker.data.room.LocationEntity
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    viewModel: LocationViewModel = hiltViewModel()
) {
    val history by viewModel.locationHistory.collectAsState()
    val currentLocation = history.firstOrNull()
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize()) {
        // Map Section
        Box(modifier = Modifier.weight(1f)) {
            val cameraPositionState = rememberCameraPositionState()
            
            LaunchedEffect(currentLocation) {
                currentLocation?.let {
                    cameraPositionState.position = CameraPosition.fromLatLngZoom(
                        LatLng(it.latitude, it.longitude),
                        15f
                    )
                }
            }

            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState
            ) {
                currentLocation?.let {
                    Marker(
                        state = MarkerState(position = LatLng(it.latitude, it.longitude)),
                        title = "Current Location"
                    )
                }
                // Draw path history
                if (history.isNotEmpty()) {
                    Polyline(
                        points = history.map { LatLng(it.latitude, it.longitude) },
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Controls & Stats Section
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = { viewModel.startTracking() }) {
                    Text("Start Tracking")
                }
                Button(
                    onClick = { viewModel.stopTracking() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Stop Tracking")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Current Stats
            currentLocation?.let { loc ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Lat: ${loc.latitude}")
                        Text("Lng: ${loc.longitude}")
                        Text("Speed: ${loc.speed} m/s")
                        Text("Accuracy: ${loc.accuracy} m")
                        Text("Time: ${formatDate(loc.timestamp)}")
                        
                        Button(
                            onClick = {
                                val sendIntent: Intent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "Check my location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}")
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, null)
                                context.startActivity(shareIntent)
                            },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Text("Share Location")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            Text("History (Last 20)", style = MaterialTheme.typography.titleMedium)
            LazyColumn {
                items(history) { loc ->
                    HistoryItem(loc)
                }
            }
        }
    }
}

@Composable
fun HistoryItem(location: LocationEntity) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "${location.latitude}, ${location.longitude}",
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            text = formatDate(location.timestamp),
            style = MaterialTheme.typography.bodySmall
        )
    }
}

fun formatDate(timestamp: Long): String {
    return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
}
