package com.example.locationtracker.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "location_history")
data class LocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val latitude: Double,
    val longitude: Double,
    val speed: Float,
    val accuracy: Float,
    val timestamp: Long
)
