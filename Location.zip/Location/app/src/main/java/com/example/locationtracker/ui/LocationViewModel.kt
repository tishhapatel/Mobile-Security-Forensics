package com.example.locationtracker.ui

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.locationtracker.data.room.LocationDao
import com.example.locationtracker.data.room.LocationEntity
import com.example.locationtracker.service.LocationService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class LocationViewModel @Inject constructor(
    private val locationDao: LocationDao,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val locationHistory = locationDao.getLastLocations()
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    fun startTracking() {
        Intent(context, LocationService::class.java).also {
            it.action = LocationService.ACTION_START
            context.startService(it)
        }
    }

    fun stopTracking() {
        Intent(context, LocationService::class.java).also {
            it.action = LocationService.ACTION_STOP
            context.startService(it)
        }
    }
}
