package com.example.loginpage

import org.junit.Test
import org.junit.Assert.*

class LoginLogicTest {

    @Test
    fun testEmailValidation() {
        // Test valid email
        assertTrue(validateEmail("test@example.com"))
        assertTrue(validateEmail("user.name@domain.co.uk"))
        
        // Test invalid email
        assertFalse(validateEmail("invalid-email"))
        assertFalse(validateEmail("test@"))
        assertFalse(validateEmail("@domain.com"))
        assertFalse(validateEmail(""))
    }

    @Test
    fun testPasswordValidation() {
        // Test valid password (minimum 6 characters)
        assertTrue(validatePassword("password123"))
        assertTrue(validatePassword("123456"))
        
        // Test invalid password
        assertFalse(validatePassword("12345")) // Less than 6 characters
        assertFalse(validatePassword(""))
    }

    @Test
    fun testCredentialValidation() {
        // Test valid credentials
        assertTrue(validateCredentials("test@example.com", "password123"))
        
        // Test invalid credentials
        assertFalse(validateCredentials("invalid-email", "password123"))
        assertFalse(validateCredentials("test@example.com", "12345"))
        assertFalse(validateCredentials("", ""))
    }

    // Helper functions that mirror the logic in MainActivity
    private fun validateEmail(email: String): Boolean {
        return email.contains("@") && email.contains(".")
    }

    private fun validatePassword(password: String): Boolean {
        return password.length >= 6
    }

    private fun validateCredentials(email: String, password: String): Boolean {
        return validateEmail(email) && validatePassword(password)
    }
}