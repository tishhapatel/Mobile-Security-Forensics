package com.example.calculator

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.calculator.databinding.FragmentFirstBinding
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private var currentInput = StringBuilder()
    private var accumulator: BigDecimal? = null
    private var pendingOp: Char? = null
    private var lastPressedEquals = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupDigitButtons()
        setupOperatorButtons()
        setupUtilityButtons()
        updateDisplay()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupDigitButtons() {
        val digits = listOf(
            binding.btn0 to '0',
            binding.btn1 to '1',
            binding.btn2 to '2',
            binding.btn3 to '3',
            binding.btn4 to '4',
            binding.btn5 to '5',
            binding.btn6 to '6',
            binding.btn7 to '7',
            binding.btn8 to '8',
            binding.btn9 to '9'
        )
        digits.forEach { (btn, ch) ->
            btn.setOnClickListener {
                if (lastPressedEquals) {
                    clearAll()
                }
                if (!(ch == '0' && currentInput.isEmpty())) {
                    currentInput.append(ch)
                } else if (currentInput.isNotEmpty()) {
                    currentInput.append(ch)
                } else {
                    currentInput.append(ch) // allow single leading zero
                }
                updateDisplay()
            }
        }
        binding.btnDot.setOnClickListener {
            if (lastPressedEquals) {
                clearAll()
            }
            if (!currentInput.contains('.')) {
                if (currentInput.isEmpty()) currentInput.append('0')
                currentInput.append('.')
                updateDisplay()
            }
        }
    }

    private fun setupOperatorButtons() {
        binding.btnPlus.setOnClickListener { applyOperator('+') }
        binding.btnMinus.setOnClickListener { applyOperator('-') }
        binding.btnMultiply.setOnClickListener { applyOperator('×') }
        binding.btnDivide.setOnClickListener { applyOperator('÷') }
        binding.btnPercent.setOnClickListener { applyPercent() }
        binding.btnEquals.setOnClickListener { evaluateEquals() }
    }

    private fun setupUtilityButtons() {
        binding.btnClear.setOnClickListener {
            clearAll()
            updateDisplay()
        }
        binding.btnDelete.setOnClickListener {
            if (currentInput.isNotEmpty()) {
                currentInput.deleteCharAt(currentInput.length - 1)
            }
            updateDisplay()
        }
        binding.btnSign.setOnClickListener {
            if (currentInput.isNotEmpty()) {
                if (currentInput.startsWith("-")) {
                    currentInput.deleteCharAt(0)
                } else {
                    currentInput.insert(0, "-")
                }
                updateDisplay()
            } else if (accumulator != null) {
                accumulator = accumulator!!.negate()
                updateDisplay()
            }
        }
    }

    private fun applyOperator(op: Char) {
        if (currentInput.isNotEmpty()) {
            val value = currentInput.toBigDecimalSafe()
            accumulator = when {
                accumulator == null -> value
                pendingOp != null -> compute(accumulator!!, value, pendingOp!!)
                else -> value
            }
            currentInput.clear()
        } else if (accumulator == null) {
            accumulator = BigDecimal.ZERO
        }
        pendingOp = op
        lastPressedEquals = false
        updateDisplay()
    }

    private fun applyPercent() {
        if (currentInput.isNotEmpty()) {
            val value = currentInput.toBigDecimalSafe()
            val percent = value.divide(BigDecimal(100), 10, RoundingMode.HALF_UP)
            currentInput.clear()
            currentInput.append(percent.stripTrailingZeros().toPlainString())
        } else if (accumulator != null) {
            accumulator = accumulator!!.divide(BigDecimal(100), 10, RoundingMode.HALF_UP)
        }
        updateDisplay()
    }

    private fun evaluateEquals() {
        if (pendingOp != null && accumulator != null && currentInput.isNotEmpty()) {
            val rhs = currentInput.toBigDecimalSafe()
            val result = compute(accumulator!!, rhs, pendingOp!!)
            accumulator = result
            currentInput.clear()
            pendingOp = null
            lastPressedEquals = true
            updateDisplay()
        }
    }

    private fun compute(a: BigDecimal, b: BigDecimal, op: Char): BigDecimal {
        return when (op) {
            '+' -> a.add(b)
            '-' -> a.subtract(b)
            '×' -> a.multiply(b)
            '÷' -> {
                if (b.compareTo(BigDecimal.ZERO) == 0) {
                    BigDecimal.ZERO
                } else {
                    a.divide(b, 10, RoundingMode.HALF_UP)
                }
            }
            else -> a
        }
    }

    private fun updateDisplay() {
        val text = when {
            currentInput.isNotEmpty() -> currentInput.toString()
            accumulator != null -> accumulator!!.stripTrailingZeros().toPlainString()
            else -> "0"
        }
        binding.displayText.text = text
    }

    private fun clearAll() {
        currentInput.clear()
        accumulator = null
        pendingOp = null
        lastPressedEquals = false
    }

    private fun StringBuilder.toBigDecimalSafe(): BigDecimal {
        return if (this.isEmpty() || this.toString() == "-") {
            BigDecimal.ZERO
        } else {
            try {
                BigDecimal(this.toString())
            } catch (_: NumberFormatException) {
                BigDecimal.ZERO
            }
        }
    }
}
